# SET Framework

**Social Engineering Toolkit for Assessment**

Agentic OSINT harvesting + PHLRA psychological profiling for social engineering vulnerability assessment.

## Overview

SET Framework automates the reconnaissance and analysis phases of social engineering assessments:

1. **Agentic Discovery Loop** - LLM-driven tool orchestration that iteratively discovers information
2. **Multi-Tool Harvesting** - Integrates Sherlock, Maigret, Holehe, GitHub API, HIBP, and more
3. **PHLRA Analysis** - Psychological profiling using the PHLRA framework (Psychological, Hierarchical, Logical, Relational, Asset-based)
4. **Vulnerability Mapping** - Maps psychological profile to exploitable vulnerabilities
5. **Attack Design** - Generates personalized attack scenarios with pretexts
6. **Defense Recommendations** - Targeted training and controls

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      SEED INPUT                             │
│           (name, email, username, domain)                   │
└─────────────────────────┬───────────────────────────────────┘
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                    DISCOVERY LOOP                           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │                                                      │   │
│  │   RUN TOOLS ──▶ PARSE ──▶ UPDATE PROFILE            │   │
│  │       ▲                         │                    │   │
│  │       │                         ▼                    │   │
│  │   SELECT    ◀── LLM ◀── ANALYZE GAPS                │   │
│  │   NEXT TOOL     DECIDES                              │   │
│  │                                                      │   │
│  └─────────────────────────────────────────────────────┘   │
│               Loop until saturated or max iterations        │
└─────────────────────────┬───────────────────────────────────┘
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                    ANALYSIS PIPELINE                        │
│       PHLRA → Vulnerabilities → Attacks → Defenses          │
└─────────────────────────────────────────────────────────────┘
```

## Installation

```bash
# Clone the repo
git clone https://github.com/yourrepo/set-framework.git
cd set-framework

# Create virtual environment
python -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows

# Install dependencies
pip install -r requirements.txt

# Install OSINT tools
pip install sherlock-project maigret holehe

# Initialize config
python set.py init
```

## Configuration

Edit `config.yaml`:

```yaml
llm:
  provider: claude  # or ollama
  model: claude-sonnet-4-20250514
  api_key: ${ANTHROPIC_API_KEY}  # or set directly

tools:
  enabled:
    - sherlock
    - maigret
    - holehe
    - github
    - hibp
```

Set environment variables:
```bash
export ANTHROPIC_API_KEY="your-key"
export HIBP_API_KEY="your-key"  # Optional, for breach data
```

## Usage

### Full Assessment

```bash
# Basic run with name and email
python set.py run --target "John Doe" --email john@company.com

# With more seed data
python set.py run \
  --target "John Doe" \
  --email john@company.com \
  --company "Acme Corp" \
  --role "VP Engineering" \
  --linkedin "johndoe" \
  --github "johndoe" \
  --domain "acme.com"

# Control iteration depth
python set.py run --target "John Doe" --email john@company.com --max-iterations 15
```

### Analysis Only

```bash
# Run analysis on existing profile
python set.py analyze --profile data/profiles/john-doe.json
```

### Generate Reports

```bash
# Markdown report
python set.py report --profile data/profiles/john-doe.json --format markdown

# HTML report
python set.py report --profile data/profiles/john-doe.json --format html

# PDF report (requires weasyprint)
python set.py report --profile data/profiles/john-doe.json --format pdf
```

### Check Available Tools

```bash
python set.py tools
```

## PHLRA Framework

The framework analyzes targets across five dimensions:

| Dimension | Focus | Key Indicators |
|-----------|-------|----------------|
| **P** - Psychological | Cognitive vulnerabilities | Big Five traits, biases, hubris, thinking style |
| **H** - Hierarchical | Authority dynamics | Seniority, compliance, power distance |
| **L** - Logical | Technical/Digital | Digital footprint, tech sophistication, OPSEC |
| **R** - Relational | Trust networks | Trust anchors, in-groups, influence susceptibility |
| **A** - Asset-based | Target value | Access levels, lateral movement potential |

## Tools Integrated

| Tool | Input | Output |
|------|-------|--------|
| **Sherlock** | username | Accounts on 400+ sites |
| **Maigret** | username | Accounts on 2500+ sites + profile parsing |
| **Holehe** | email | Account existence on 100+ sites |
| **GitHub API** | username/email | Profile, repos, activity, commit messages |
| **HIBP** | email | Breach history, paste appearances |
| **theHarvester** | domain/name | Emails, subdomains, names |

## Output Structure

```
data/
├── profiles/
│   └── john-doe-20240115-143022.json  # Full profile with findings
└── reports/
    ├── john-doe-report.md
    ├── john-doe-report.html
    └── john-doe-report.pdf
```

## Profile JSON Structure

```json
{
  "name": "John Doe",
  "company": "Acme Corp",
  "role": "VP Engineering",
  "identifiers": {
    "emails": ["john@acme.com"],
    "usernames": ["johndoe", "jdoe"],
    "linkedin": "johndoe",
    "twitter": "johndoe_dev",
    "github": "johndoe"
  },
  "accounts": [...],
  "content": [...],
  "behavioral": {
    "signals": [...],
    "quotes": [...],
    "hubris_indicators": [...]
  },
  "phlra_scores": {
    "psychological": {"score": 7, "confidence": "high", ...},
    "hierarchical": {"score": 5, ...},
    "logical": {"score": 8, ...},
    "relational": {"score": 6, ...},
    "asset_based": {"score": 7, ...},
    "behavioral_risk_score": 72,
    "vulnerabilities": [...],
    "attacks": {...},
    "defenses": {...}
  }
}
```

## Extending

### Add a New Tool

1. Create `tools/newtool.py`:

```python
from tools.base import CLITool  # or PythonModuleTool, APITool
from core.profile import Finding

class NewTool(CLITool):
    name = "newtool"
    description = "What it does"
    input_types = ["email", "username"]  # What inputs it accepts
    binary_names = ["newtool", "new-tool"]  # Binary names to search
    
    def run(self, input_value, input_type, timeout=120):
        findings = []
        # ... run tool, parse output
        findings.append(Finding(
            source=self.name,
            category="account",  # or email, profile, content, behavioral, breach
            platform="somesite",
            data={"username": "...", "url": "..."},
            confidence=0.8,
            phlra_relevant=["L", "R"]
        ))
        return findings
```

2. Register in `tools/__init__.py`:
```python
from tools.newtool import NewTool
AVAILABLE_TOOLS["newtool"] = NewTool
```

3. Enable in config.yaml

### Local LLM with Ollama

```yaml
llm:
  provider: ollama
  model: llama3.1:70b  # or mixtral, etc.
  endpoint: http://localhost:11434
```

Run Ollama:
```bash
ollama run llama3.1:70b
```

## Ethical Use

This tool is designed for **authorized security assessments only**. 

- Only use on targets you have explicit permission to assess
- Follow your organization's security testing policies
- Respect rate limits and terms of service of third-party services
- Handle collected data responsibly
- Use findings to improve security, not to cause harm

## Credits

- PHLRA Framework: Kai Aizen (Adversarial Minds)
- OSINT Tools: Sherlock Project, soxoj/maigret, megadose/holehe
- Inspired by: theHarvester, SpiderFoot, Maltego

## License

MIT License - See LICENSE file
