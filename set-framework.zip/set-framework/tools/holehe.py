"""
Holehe - Check if email is used on various sites.
https://github.com/megadose/holehe
"""

import json
from typing import List

from tools.base import PythonModuleTool
from core.profile import Finding


class HoleheTool(PythonModuleTool):
    name = "holehe"
    description = "Check if email is attached to an account on sites like Twitter, Instagram, etc."
    input_types = ["email"]
    module_name = "holehe"
    
    def run(self, input_value: str, input_type: str = "email", timeout: int = 120) -> List[Finding]:
        if input_type != "email":
            return []
        
        if not self.is_available():
            raise RuntimeError("Holehe not installed. Install with: pip install holehe")
        
        findings = []
        
        try:
            import asyncio
            import httpx
            from holehe import core as holehe_core
            
            # Get all modules
            modules = holehe_core.import_submodules("holehe.modules")
            
            async def check_all():
                results = []
                async with httpx.AsyncClient(timeout=10.0) as client:
                    for module_name, module in modules.items():
                        if hasattr(module, module_name.split(".")[-1]):
                            func = getattr(module, module_name.split(".")[-1])
                            try:
                                out = []
                                await func(input_value, client, out)
                                results.extend(out)
                            except Exception:
                                pass
                return results
            
            # Run async checks
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
            
            results = loop.run_until_complete(
                asyncio.wait_for(check_all(), timeout=timeout)
            )
            
            for result in results:
                if result.get("exists"):
                    site_name = result.get("name", "unknown")
                    
                    findings.append(Finding(
                        source=self.name,
                        category="account",
                        platform=site_name.lower(),
                        data={
                            "email": input_value,
                            "exists": True,
                            "site_name": site_name,
                            "rateLimit": result.get("rateLimit", False),
                            "emailrecovery": result.get("emailrecovery"),
                            "phoneNumber": result.get("phoneNumber"),
                            "others": result.get("others")
                        },
                        confidence=0.9 if not result.get("rateLimit") else 0.5,
                        phlra_relevant=["L"],
                        raw=json.dumps(result)
                    ))
                    
                    # If phone number found, add as identifier
                    if result.get("phoneNumber"):
                        findings.append(Finding(
                            source=self.name,
                            category="phone",
                            platform=site_name.lower(),
                            data={
                                "phone": result["phoneNumber"],
                                "from_site": site_name
                            },
                            confidence=0.7
                        ))
        
        except asyncio.TimeoutError:
            raise TimeoutError(f"Holehe timed out after {timeout}s")
        except Exception as e:
            raise RuntimeError(f"Holehe error: {e}")
        
        return findings
