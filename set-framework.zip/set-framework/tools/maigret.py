"""
Maigret - Advanced username enumeration with profile parsing.
https://github.com/soxoj/maigret
"""

import json
import os
import tempfile
from typing import List

from tools.base import CLITool
from core.profile import Finding


class MaigretTool(CLITool):
    name = "maigret"
    description = "Collect person's accounts with username across 2500+ sites with profile parsing"
    input_types = ["username"]
    binary_names = ["maigret"]
    
    def run(self, input_value: str, input_type: str = "username", timeout: int = 180) -> List[Finding]:
        if input_type != "username":
            return []
        
        if not self.is_available():
            raise RuntimeError("Maigret not installed. Install with: pip install maigret")
        
        findings = []
        
        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = os.path.join(tmpdir, "report.json")
            
            cmd = [
                self.binary_path,
                input_value,
                "--json", "simple",
                "-o", output_file,
                "--timeout", "10",
                "--no-progressbar"
            ]
            
            try:
                self._run_command(cmd, timeout)
                
                if os.path.exists(output_file):
                    with open(output_file) as f:
                        results = json.load(f)
                    
                    # Maigret returns dict with username as key
                    user_data = results.get(input_value, {})
                    sites = user_data.get("sites", {})
                    
                    for site_name, data in sites.items():
                        status = data.get("status", {})
                        if status.get("status") == "Claimed":
                            # Extract profile data if available
                            profile_data = {
                                "username": input_value,
                                "url": data.get("url_user"),
                                "exists": True,
                                "site_name": site_name
                            }
                            
                            # Maigret extracts additional info
                            if data.get("ids"):
                                profile_data["ids"] = data["ids"]
                            if data.get("parsed"):
                                profile_data["parsed"] = data["parsed"]
                            
                            # Determine PHLRA relevance
                            phlra = ["L"]  # Digital footprint
                            if site_name.lower() in ["linkedin", "indeed", "glassdoor"]:
                                phlra.append("H")  # Professional/hierarchical
                            if site_name.lower() in ["twitter", "facebook", "instagram"]:
                                phlra.append("R")  # Relational
                            
                            findings.append(Finding(
                                source=self.name,
                                category="account",
                                platform=site_name.lower(),
                                data=profile_data,
                                confidence=0.9,
                                phlra_relevant=phlra,
                                raw=json.dumps(data)
                            ))
                            
                            # If parsed profile data, add as separate finding
                            if data.get("parsed"):
                                findings.append(Finding(
                                    source=self.name,
                                    category="profile",
                                    platform=site_name.lower(),
                                    data=data["parsed"],
                                    confidence=0.85,
                                    phlra_relevant=phlra
                                ))
            
            except Exception as e:
                raise RuntimeError(f"Maigret error: {e}")
        
        return findings
