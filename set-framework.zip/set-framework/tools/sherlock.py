"""
Sherlock - Username enumeration across social networks.
https://github.com/sherlock-project/sherlock
"""

import json
import os
import tempfile
from typing import List

from tools.base import CLITool
from core.profile import Finding


class SherlockTool(CLITool):
    name = "sherlock"
    description = "Hunt usernames across 400+ social networks"
    input_types = ["username"]
    binary_names = ["sherlock"]
    
    def run(self, input_value: str, input_type: str = "username", timeout: int = 120) -> List[Finding]:
        if input_type != "username":
            return []
        
        if not self.is_available():
            raise RuntimeError("Sherlock not installed. Install with: pip install sherlock-project")
        
        findings = []
        
        # Run sherlock with JSON output
        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = os.path.join(tmpdir, f"{input_value}.json")
            
            cmd = [
                self.binary_path,
                input_value,
                "--json", output_file,
                "--timeout", "10",
                "--print-found"
            ]
            
            try:
                output = self._run_command(cmd, timeout)
                
                # Parse JSON results
                if os.path.exists(output_file):
                    with open(output_file) as f:
                        results = json.load(f)
                    
                    for site_name, data in results.items():
                        if data.get("status") == "Claimed":
                            findings.append(Finding(
                                source=self.name,
                                category="account",
                                platform=site_name.lower(),
                                data={
                                    "username": input_value,
                                    "url": data.get("url_user"),
                                    "exists": True,
                                    "site_name": site_name
                                },
                                confidence=0.85,
                                phlra_relevant=["L"],  # Logical - digital footprint
                                raw=json.dumps(data)
                            ))
                else:
                    # Parse from stdout if JSON failed
                    for line in output.split("\n"):
                        if "[+]" in line and "http" in line:
                            # Extract URL from line like "[+] SiteName: https://..."
                            parts = line.split(": ", 1)
                            if len(parts) == 2:
                                site = parts[0].replace("[+]", "").strip()
                                url = parts[1].strip()
                                findings.append(Finding(
                                    source=self.name,
                                    category="account",
                                    platform=site.lower(),
                                    data={
                                        "username": input_value,
                                        "url": url,
                                        "exists": True
                                    },
                                    confidence=0.8
                                ))
            except Exception as e:
                raise RuntimeError(f"Sherlock error: {e}")
        
        return findings
