"""
Tool wrappers for OSINT tools.
Each tool implements a common interface for the agent loop.
"""

from tools.base import BaseTool
from tools.sherlock import SherlockTool
from tools.maigret import MaigretTool
from tools.holehe import HoleheTool
from tools.github import GitHubTool
from tools.hibp import HIBPTool
from tools.theharvester import TheHarvesterTool

# Registry of available tools
AVAILABLE_TOOLS = {
    "sherlock": SherlockTool,
    "maigret": MaigretTool,
    "holehe": HoleheTool,
    "github": GitHubTool,
    "hibp": HIBPTool,
    "theharvester": TheHarvesterTool,
}


def get_tool(name: str) -> BaseTool:
    """Get tool instance by name."""
    tool_class = AVAILABLE_TOOLS.get(name)
    if tool_class:
        return tool_class()
    return None


def list_tools() -> dict:
    """List all available tools and their status."""
    status = {}
    for name, tool_class in AVAILABLE_TOOLS.items():
        tool = tool_class()
        status[name] = {
            "available": tool.is_available(),
            "input_types": tool.input_types,
            "description": tool.description
        }
    return status
