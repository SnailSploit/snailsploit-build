"""
theHarvester - Email, subdomain, and name harvesting.
https://github.com/laramies/theHarvester
"""

import json
import os
import tempfile
import re
from typing import List

from tools.base import CLITool
from core.profile import Finding


class TheHarvesterTool(CLITool):
    name = "theharvester"
    description = "Gather emails, subdomains, hosts, names from public sources"
    input_types = ["domain", "name"]
    binary_names = ["theHarvester", "theharvester"]
    
    def run(self, input_value: str, input_type: str = "domain", timeout: int = 180) -> List[Finding]:
        if input_type not in ["domain", "name"]:
            return []
        
        if not self.is_available():
            raise RuntimeError("theHarvester not installed. Install with: pip install theHarvester")
        
        findings = []
        
        # Data sources to use
        sources = "bing,duckduckgo,google,linkedin,twitter,yahoo"
        
        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = os.path.join(tmpdir, "results.json")
            
            cmd = [
                self.binary_path,
                "-d", input_value,
                "-b", sources,
                "-f", output_file.replace(".json", ""),  # theHarvester adds extension
                "-l", "100"  # Limit results
            ]
            
            try:
                output = self._run_command(cmd, timeout)
                
                # Try to read JSON output
                json_file = output_file if os.path.exists(output_file) else output_file.replace(".json", ".xml")
                
                if os.path.exists(output_file):
                    with open(output_file) as f:
                        try:
                            results = json.load(f)
                        except json.JSONDecodeError:
                            results = {}
                    
                    # Process emails
                    emails = results.get("emails", [])
                    for email in emails:
                        if isinstance(email, str) and "@" in email:
                            findings.append(Finding(
                                source=self.name,
                                category="email",
                                platform=None,
                                data={
                                    "email": email.lower().strip(),
                                    "domain": input_value
                                },
                                confidence=0.8,
                                phlra_relevant=["L"]
                            ))
                    
                    # Process hosts
                    hosts = results.get("hosts", [])
                    for host in hosts[:20]:  # Limit
                        if isinstance(host, str):
                            findings.append(Finding(
                                source=self.name,
                                category="infrastructure",
                                platform=None,
                                data={
                                    "host": host,
                                    "domain": input_value
                                },
                                confidence=0.7
                            ))
                    
                    # Process LinkedIn users found
                    linkedin_users = results.get("linkedin_people", []) or results.get("people", [])
                    for person in linkedin_users[:10]:
                        if isinstance(person, str):
                            findings.append(Finding(
                                source=self.name,
                                category="profile",
                                platform="linkedin",
                                data={
                                    "name": person,
                                    "domain": input_value
                                },
                                confidence=0.6,
                                phlra_relevant=["R"]
                            ))
                
                else:
                    # Parse from stdout
                    self._parse_stdout(output, input_value, findings)
                
            except Exception as e:
                raise RuntimeError(f"theHarvester error: {e}")
        
        return findings
    
    def _parse_stdout(self, output: str, domain: str, findings: List[Finding]):
        """Parse theHarvester stdout if JSON not available."""
        
        # Find emails
        email_pattern = r'[\w\.-]+@[\w\.-]+\.\w+'
        emails = set(re.findall(email_pattern, output.lower()))
        
        for email in emails:
            if domain.lower() in email or len(emails) < 10:  # Filter to relevant
                findings.append(Finding(
                    source=self.name,
                    category="email",
                    platform=None,
                    data={
                        "email": email,
                        "domain": domain
                    },
                    confidence=0.7
                ))
        
        # Find subdomains
        subdomain_pattern = rf'([\w\.-]+\.{re.escape(domain)})'
        subdomains = set(re.findall(subdomain_pattern, output.lower()))
        
        for sub in list(subdomains)[:20]:
            findings.append(Finding(
                source=self.name,
                category="infrastructure",
                platform=None,
                data={
                    "host": sub,
                    "domain": domain
                },
                confidence=0.7
            ))
