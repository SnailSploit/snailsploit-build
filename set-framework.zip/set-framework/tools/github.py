"""
GitHub API - Extract profile, repos, activity, and commit messages.
No auth needed for public data.
"""

import json
import requests
from typing import List

from tools.base import BaseTool
from core.profile import Finding


class GitHubTool(BaseTool):
    name = "github"
    description = "Fetch GitHub profile, repos, activity, and commit messages (behavioral analysis)"
    input_types = ["username", "email"]
    
    API_BASE = "https://api.github.com"
    
    def __init__(self, token: str = None):
        super().__init__()
        import os
        self.token = token or os.environ.get("GITHUB_TOKEN", "")
        self.headers = {"Accept": "application/vnd.github.v3+json"}
        if self.token:
            self.headers["Authorization"] = f"token {self.token}"
    
    def is_available(self) -> bool:
        """GitHub API is always available (rate-limited without token)."""
        return True
    
    def run(self, input_value: str, input_type: str = "username", timeout: int = 60) -> List[Finding]:
        findings = []
        
        username = input_value
        
        # If email, search for user first
        if input_type == "email":
            users = self._search_by_email(input_value)
            if users:
                # Add email association findings
                for user in users[:3]:  # Max 3 users per email
                    findings.append(Finding(
                        source=self.name,
                        category="username",
                        platform="github",
                        data={
                            "username": user["login"],
                            "email": input_value,
                            "url": user["html_url"]
                        },
                        confidence=0.7
                    ))
                username = users[0]["login"]
            else:
                return findings
        
        # Clean username
        username = username.replace("https://github.com/", "").split("/")[0].strip()
        
        try:
            # Fetch profile
            profile = self._get_profile(username)
            if not profile:
                return findings
            
            findings.append(Finding(
                source=self.name,
                category="profile",
                platform="github",
                data={
                    "username": profile["login"],
                    "name": profile.get("name"),
                    "bio": profile.get("bio"),
                    "company": profile.get("company"),
                    "location": profile.get("location"),
                    "email": profile.get("email"),
                    "blog": profile.get("blog"),
                    "twitter_username": profile.get("twitter_username"),
                    "public_repos": profile.get("public_repos"),
                    "followers": profile.get("followers"),
                    "following": profile.get("following"),
                    "created_at": profile.get("created_at"),
                    "url": profile.get("html_url"),
                    "avatar_url": profile.get("avatar_url"),
                    "hireable": profile.get("hireable")
                },
                confidence=0.95,
                phlra_relevant=["L", "P"],  # Technical + Personality from bio
                raw=json.dumps(profile)
            ))
            
            # Also add as confirmed account
            findings.append(Finding(
                source=self.name,
                category="account",
                platform="github",
                data={
                    "username": profile["login"],
                    "url": profile["html_url"],
                    "exists": True
                },
                confidence=0.95
            ))
            
            # If Twitter username found
            if profile.get("twitter_username"):
                findings.append(Finding(
                    source=self.name,
                    category="username",
                    platform="twitter",
                    data={
                        "username": profile["twitter_username"],
                        "from_github": True
                    },
                    confidence=0.9
                ))
            
            # Fetch repos for language/skill analysis
            repos = self._get_repos(username)
            languages = {}
            topics = []
            
            for repo in repos[:10]:  # Top 10 repos
                if repo.get("language"):
                    languages[repo["language"]] = languages.get(repo["language"], 0) + 1
                if repo.get("topics"):
                    topics.extend(repo["topics"])
            
            if languages:
                findings.append(Finding(
                    source=self.name,
                    category="behavioral",
                    platform="github",
                    data={
                        "type": "technical_skills",
                        "signal": "Programming languages and expertise",
                        "evidence": {
                            "languages": languages,
                            "topics": list(set(topics)),
                            "repo_count": len(repos)
                        }
                    },
                    confidence=0.9,
                    phlra_relevant=["L"]
                ))
            
            # Fetch recent events for activity patterns
            events = self._get_events(username)
            event_types = {}
            commit_messages = []
            pr_comments = []
            issue_comments = []
            
            for event in events[:30]:
                event_type = event.get("type")
                event_types[event_type] = event_types.get(event_type, 0) + 1
                
                payload = event.get("payload", {})
                
                # Extract commit messages (communication style)
                if event_type == "PushEvent":
                    for commit in payload.get("commits", []):
                        if commit.get("message"):
                            commit_messages.append(commit["message"][:200])
                
                # Extract PR/issue comments
                elif event_type in ["IssueCommentEvent", "PullRequestReviewCommentEvent"]:
                    if payload.get("comment", {}).get("body"):
                        comment = payload["comment"]["body"][:300]
                        if event_type == "PullRequestReviewCommentEvent":
                            pr_comments.append(comment)
                        else:
                            issue_comments.append(comment)
            
            # Add commit messages as content (for behavioral analysis)
            if commit_messages:
                findings.append(Finding(
                    source=self.name,
                    category="content",
                    platform="github",
                    data={
                        "type": "commit_messages",
                        "text": "\n---\n".join(commit_messages[:10]),
                        "count": len(commit_messages)
                    },
                    confidence=0.9,
                    phlra_relevant=["P", "L"]  # Psychological (style) + Logical
                ))
            
            if pr_comments or issue_comments:
                findings.append(Finding(
                    source=self.name,
                    category="content",
                    platform="github",
                    data={
                        "type": "comments",
                        "pr_comments": pr_comments[:5],
                        "issue_comments": issue_comments[:5]
                    },
                    confidence=0.9,
                    phlra_relevant=["P", "R"]  # Style + how they interact
                ))
            
            # Activity pattern
            if event_types:
                findings.append(Finding(
                    source=self.name,
                    category="behavioral",
                    platform="github",
                    data={
                        "type": "activity_pattern",
                        "signal": "GitHub activity patterns",
                        "evidence": {
                            "event_types": event_types,
                            "total_recent_events": len(events)
                        }
                    },
                    confidence=0.85,
                    phlra_relevant=["L"]
                ))
        
        except Exception as e:
            raise RuntimeError(f"GitHub API error: {e}")
        
        return findings
    
    def _get_profile(self, username: str) -> dict:
        """Fetch user profile."""
        resp = requests.get(f"{self.API_BASE}/users/{username}", headers=self.headers)
        if resp.status_code == 200:
            return resp.json()
        return None
    
    def _get_repos(self, username: str) -> list:
        """Fetch user repos."""
        resp = requests.get(
            f"{self.API_BASE}/users/{username}/repos",
            headers=self.headers,
            params={"sort": "updated", "per_page": 30}
        )
        if resp.status_code == 200:
            return resp.json()
        return []
    
    def _get_events(self, username: str) -> list:
        """Fetch user events."""
        resp = requests.get(
            f"{self.API_BASE}/users/{username}/events/public",
            headers=self.headers,
            params={"per_page": 100}
        )
        if resp.status_code == 200:
            return resp.json()
        return []
    
    def _search_by_email(self, email: str) -> list:
        """Search for users by email."""
        resp = requests.get(
            f"{self.API_BASE}/search/users",
            headers=self.headers,
            params={"q": f"{email} in:email"}
        )
        if resp.status_code == 200:
            return resp.json().get("items", [])
        return []
