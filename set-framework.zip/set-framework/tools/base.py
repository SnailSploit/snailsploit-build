"""
Base class for all OSINT tool wrappers.
"""

from abc import ABC, abstractmethod
from typing import List, Optional
import subprocess
import shutil

from core.profile import Finding


class BaseTool(ABC):
    """Base class for tool wrappers."""
    
    name: str = "base"
    description: str = "Base tool"
    input_types: List[str] = []  # email, username, name, domain, phone
    
    def __init__(self):
        self.binary_path = None
    
    @abstractmethod
    def is_available(self) -> bool:
        """Check if tool is installed and available."""
        pass
    
    @abstractmethod
    def run(self, input_value: str, input_type: str, timeout: int = 120) -> List[Finding]:
        """
        Run the tool and return findings.
        
        Args:
            input_value: The value to search for
            input_type: Type of input (email, username, etc.)
            timeout: Max seconds to wait
            
        Returns:
            List of Finding objects
        """
        pass
    
    def _run_command(self, cmd: List[str], timeout: int = 120) -> str:
        """Run a shell command and return output."""
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return result.stdout + result.stderr
        except subprocess.TimeoutExpired:
            raise TimeoutError(f"{self.name} timed out after {timeout}s")
        except Exception as e:
            raise RuntimeError(f"{self.name} error: {e}")
    
    def _find_binary(self, names: List[str]) -> Optional[str]:
        """Find binary in PATH."""
        for name in names:
            path = shutil.which(name)
            if path:
                return path
        return None


class PythonModuleTool(BaseTool):
    """Base for tools that are Python modules (can be imported)."""
    
    module_name: str = None
    
    def is_available(self) -> bool:
        """Check if module is importable."""
        try:
            __import__(self.module_name)
            return True
        except ImportError:
            return False


class APITool(BaseTool):
    """Base for tools that use APIs."""
    
    api_key_env: str = None
    api_key: str = None
    
    def __init__(self, api_key: str = None):
        super().__init__()
        import os
        self.api_key = api_key or os.environ.get(self.api_key_env, "")
    
    def is_available(self) -> bool:
        """Check if API key is configured."""
        return bool(self.api_key)


class CLITool(BaseTool):
    """Base for command-line tools."""
    
    binary_names: List[str] = []
    
    def is_available(self) -> bool:
        """Check if binary is in PATH."""
        self.binary_path = self._find_binary(self.binary_names)
        return self.binary_path is not None
