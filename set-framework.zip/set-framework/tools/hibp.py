"""
Have I Been Pwned API - Check for breached accounts.
Requires API key for full functionality.
"""

import requests
import time
from typing import List

from tools.base import APITool
from core.profile import Finding


class HIBPTool(APITool):
    name = "hibp"
    description = "Check if email appears in known data breaches (security awareness indicator)"
    input_types = ["email"]
    api_key_env = "HIBP_API_KEY"
    
    API_BASE = "https://haveibeenpwned.com/api/v3"
    
    def is_available(self) -> bool:
        """HIBP requires API key for breach data."""
        # Can still check pastes without key
        return True
    
    def run(self, input_value: str, input_type: str = "email", timeout: int = 30) -> List[Finding]:
        if input_type != "email":
            return []
        
        findings = []
        headers = {
            "User-Agent": "SET-Framework-OSINT",
            "Accept": "application/json"
        }
        
        if self.api_key:
            headers["hibp-api-key"] = self.api_key
        
        try:
            # Check breaches (requires API key)
            if self.api_key:
                resp = requests.get(
                    f"{self.API_BASE}/breachedaccount/{input_value}",
                    headers=headers,
                    params={"truncateResponse": "false"},
                    timeout=timeout
                )
                
                if resp.status_code == 200:
                    breaches = resp.json()
                    
                    findings.append(Finding(
                        source=self.name,
                        category="breach",
                        platform="hibp",
                        data={
                            "email": input_value,
                            "pwned": True,
                            "breach_count": len(breaches),
                            "breaches": [
                                {
                                    "name": b.get("Name"),
                                    "domain": b.get("Domain"),
                                    "date": b.get("BreachDate"),
                                    "data_classes": b.get("DataClasses", []),
                                    "is_verified": b.get("IsVerified"),
                                    "is_sensitive": b.get("IsSensitive")
                                }
                                for b in breaches
                            ]
                        },
                        confidence=0.95,
                        phlra_relevant=["L", "P"],  # Security posture + risk awareness
                        raw=str(breaches)
                    ))
                    
                    # Add behavioral signal about security awareness
                    sensitive_breaches = [b for b in breaches if b.get("IsSensitive")]
                    password_breaches = [b for b in breaches if "Passwords" in b.get("DataClasses", [])]
                    
                    if password_breaches:
                        findings.append(Finding(
                            source=self.name,
                            category="behavioral",
                            platform="hibp",
                            data={
                                "type": "security_awareness",
                                "signal": "Password exposed in breaches",
                                "evidence": {
                                    "password_breaches": len(password_breaches),
                                    "total_breaches": len(breaches),
                                    "breach_names": [b.get("Name") for b in password_breaches]
                                }
                            },
                            confidence=0.9,
                            phlra_relevant=["L", "P"]
                        ))
                
                elif resp.status_code == 404:
                    # No breaches found
                    findings.append(Finding(
                        source=self.name,
                        category="breach",
                        platform="hibp",
                        data={
                            "email": input_value,
                            "pwned": False,
                            "breach_count": 0
                        },
                        confidence=0.95,
                        phlra_relevant=["L"]
                    ))
                
                elif resp.status_code == 429:
                    raise RuntimeError("HIBP rate limited - try again later")
            
            # Check pastes (no API key needed, but rate limited)
            time.sleep(1.6)  # Rate limit
            
            resp = requests.get(
                f"{self.API_BASE}/pasteaccount/{input_value}",
                headers=headers,
                timeout=timeout
            )
            
            if resp.status_code == 200:
                pastes = resp.json()
                if pastes:
                    findings.append(Finding(
                        source=self.name,
                        category="breach",
                        platform="paste",
                        data={
                            "email": input_value,
                            "paste_count": len(pastes),
                            "pastes": [
                                {
                                    "source": p.get("Source"),
                                    "id": p.get("Id"),
                                    "title": p.get("Title"),
                                    "date": p.get("Date"),
                                    "email_count": p.get("EmailCount")
                                }
                                for p in pastes[:10]  # Limit
                            ]
                        },
                        confidence=0.9,
                        phlra_relevant=["L"]
                    ))
        
        except requests.exceptions.Timeout:
            raise TimeoutError(f"HIBP timed out after {timeout}s")
        except Exception as e:
            if "rate" not in str(e).lower():
                raise RuntimeError(f"HIBP error: {e}")
        
        return findings
