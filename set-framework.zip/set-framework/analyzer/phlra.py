"""
PHLRA Framework Analyzer.
Analyzes collected intelligence to build psychological profile.
"""

import json
from core.profile import TargetProfile
from analyzer.llm import LLMClient


PHLRA_SYSTEM_PROMPT = """You are a psychological profiler specializing in social engineering vulnerability assessment using the PHLRA framework.

OUTPUT: Valid JSON only. No markdown, no explanation. Start with { end with }.

PHLRA FRAMEWORK:

**P - PSYCHOLOGICAL** (Cognitive vulnerabilities)
- Big Five personality indicators (OCEAN)
- Cognitive biases (confirmation, anchoring, availability, etc.)
- Hubris level and blind spots
- System 1 vs System 2 thinking dominance
- How they handle being wrong/criticized

**H - HIERARCHICAL** (Authority dynamics)
- Seniority level and career stage
- Authority compliance tendency
- Power distance vulnerability
- Likelihood to challenge requests
- Reporting structure awareness

**L - LOGICAL** (Technical/Digital)
- Digital footprint size and exposure
- Technical sophistication level
- OPSEC awareness
- Shadow IT risk
- Platform activity patterns

**R - RELATIONAL** (Trust networks)
- Trust anchors (people, brands, institutions they trust)
- In-group markers and communities
- Empathy triggers
- Cialdini influence susceptibility
- Social proof sensitivity

**A - ASSET-BASED** (Target value)
- Information/systems likely controlled
- Attacker value assessment
- Lateral movement potential
- Downstream access opportunities

SCORING:
- Score each dimension 1-10
- Confidence: high/medium/low based on evidence quality
- Always cite specific evidence for assessments"""


PHLRA_SCHEMA = """{
  "confidence": "high|medium|low",
  "psychological": {
    "score": 0,
    "confidence": "high|medium|low",
    "big_five": {
      "openness": {"level": "", "evidence": ""},
      "conscientiousness": {"level": "", "evidence": ""},
      "extraversion": {"level": "", "evidence": ""},
      "agreeableness": {"level": "", "evidence": ""},
      "neuroticism": {"level": "", "evidence": ""}
    },
    "cognitive_biases": [{"bias": "", "evidence": "", "exploitability": ""}],
    "hubris_level": "high|medium|low",
    "hubris_indicators": [],
    "blind_spots": [],
    "thinking_style": "",
    "criticism_response": "",
    "signals": [],
    "summary": ""
  },
  "hierarchical": {
    "score": 0,
    "confidence": "high|medium|low",
    "seniority": "executive|senior|mid|junior",
    "authority_compliance": "high|medium|low",
    "power_distance_vulnerability": "high|medium|low",
    "challenge_likelihood": "high|medium|low",
    "signals": [],
    "summary": ""
  },
  "logical": {
    "score": 0,
    "confidence": "high|medium|low",
    "digital_footprint": "large|medium|small",
    "technical_sophistication": "high|medium|low",
    "opsec_awareness": "strong|moderate|weak",
    "platforms_active": [],
    "activity_level": "",
    "signals": [],
    "summary": ""
  },
  "relational": {
    "score": 0,
    "confidence": "high|medium|low",
    "trust_anchors": [],
    "in_groups": [],
    "communities": [],
    "empathy_triggers": [],
    "influence_susceptibility": {
      "authority": "high|medium|low",
      "social_proof": "high|medium|low",
      "reciprocity": "high|medium|low",
      "liking": "high|medium|low",
      "scarcity": "high|medium|low",
      "commitment": "high|medium|low"
    },
    "signals": [],
    "summary": ""
  },
  "asset_based": {
    "score": 0,
    "confidence": "high|medium|low",
    "likely_access": [],
    "information_controlled": [],
    "target_value": "critical|high|medium|low",
    "lateral_potential": "high|medium|low",
    "signals": [],
    "summary": ""
  },
  "overall_summary": "",
  "top_vulnerabilities": [],
  "data_quality": "rich|adequate|minimal|insufficient"
}"""


class PHLRAAnalyzer:
    """Analyzes target profile using PHLRA framework."""
    
    def __init__(self, llm: LLMClient):
        self.llm = llm
    
    def analyze(self, profile: TargetProfile) -> dict:
        """Run PHLRA analysis on profile."""
        
        # Build context from profile
        context = self._build_context(profile)
        
        prompt = f"""Analyze this target using the PHLRA framework.

TARGET: {profile.name}
{f"Role: {profile.role}" if profile.role else ""}
{f"Company: {profile.company}" if profile.company else ""}

COLLECTED INTELLIGENCE:
{json.dumps(context, indent=2)}

Based on this intelligence, produce a comprehensive PHLRA analysis.
Ground every assessment in specific evidence from the data.
If data is insufficient for a dimension, note low confidence.

Return JSON matching this schema:
{PHLRA_SCHEMA}"""

        result = self.llm.complete_json(prompt, system=PHLRA_SYSTEM_PROMPT, max_tokens=4000)
        
        if result.get("parse_error"):
            return {"error": "Failed to parse PHLRA analysis", "raw": result.get("raw")}
        
        return result
    
    def _build_context(self, profile: TargetProfile) -> dict:
        """Extract relevant context from profile for analysis."""
        return {
            "accounts_found": [
                {"platform": a["platform"], "username": a.get("username")}
                for a in profile.accounts
            ],
            "breach_history": {
                "pwned": any(b.get("breach_count", 0) > 0 for b in profile.breaches),
                "breach_count": sum(b.get("breach_count", 0) for b in profile.breaches),
                "breaches": [b.get("breach_name") for b in profile.breaches if b.get("breach_name")]
            },
            "content_samples": [
                {
                    "platform": c["platform"],
                    "type": c.get("type"),
                    "text": c.get("text", "")[:500] if c.get("text") else None
                }
                for c in profile.content[:20]
            ],
            "behavioral_signals": profile.behavioral.get("signals", []),
            "quotes": profile.behavioral.get("quotes", [])[:10],
            "network_data": profile.network[:10],
            "github_profile": next(
                (a for a in profile.accounts if a["platform"] == "github"),
                None
            ),
            "technical_indicators": {
                "languages": next(
                    (f["data"].get("evidence", {}).get("languages")
                     for f in profile.findings
                     if f.data.get("type") == "technical_skills"),
                    {}
                )
            }
        }
