"""
Defense Advisor - Generates targeted defense recommendations.
"""

import json
from core.profile import TargetProfile
from analyzer.llm import LLMClient


DEFENSE_SYSTEM_PROMPT = """You are a security advisor generating targeted defense recommendations.

OUTPUT: Valid JSON only. No markdown.

DEFENSE LAYERS:
1. Individual training (address specific blind spots)
2. Simulation exercises (test against identified attack vectors)
3. Behavioral interventions (change habits/processes)
4. Technical controls (reduce attack surface)
5. Policy changes (organizational protection)
6. Monitoring (detect compromises faster)

Prioritize by:
- Impact on identified vulnerabilities
- Feasibility of implementation
- Cost/effort balance"""


DEFENSE_SCHEMA = """{
  "priority": "critical|high|medium|low",
  "quick_wins": [],
  "training": [
    {
      "topic": "",
      "priority": "immediate|short-term|long-term",
      "addresses_vulnerability": "",
      "format": "1:1|workshop|simulation|video",
      "duration": "",
      "key_points": []
    }
  ],
  "simulations": [
    {
      "id": "SIM-001",
      "set_code": "",
      "scenario": "",
      "targets_vulnerability": "",
      "difficulty": "easy|medium|hard",
      "frequency": "",
      "success_metrics": []
    }
  ],
  "behavioral_interventions": [
    {"intervention": "", "addresses": "", "implementation": ""}
  ],
  "technical_controls": [
    {"control": "", "addresses": "", "implementation": "", "cost": "low|medium|high"}
  ],
  "policy_recommendations": [],
  "monitoring": [
    {"what": "", "indicator_of": "", "alert_threshold": ""}
  ],
  "long_term": [],
  "metrics_to_track": [
    {"metric": "", "baseline": "", "target": ""}
  ]
}"""


class DefenseAdvisor:
    """Generates targeted defense recommendations."""
    
    def __init__(self, llm: LLMClient):
        self.llm = llm
    
    def recommend(self, profile: TargetProfile) -> dict:
        """Generate defense recommendations."""
        
        phlra = profile.phlra_scores
        vulns = phlra.get("vulnerabilities", [])
        attacks = phlra.get("attacks", {})
        
        prompt = f"""Generate targeted defense recommendations.

TARGET: {profile.name}
{f"Role: {profile.role}" if profile.role else ""}

VULNERABILITIES:
{json.dumps(vulns[:5], indent=2)}

RECOMMENDED ATTACKS:
{json.dumps(attacks.get('recommended_tactics', [])[:3], indent=2)}

PHLRA WEAK POINTS:
- Psychological: {phlra.get('psychological', {}).get('summary', 'N/A')}
- Hierarchical: {phlra.get('hierarchical', {}).get('summary', 'N/A')}

METRICS:
- BRS: {phlra.get('metrics', {}).get('behavioral_risk_score', 'N/A')}
- Phishing susceptibility: {phlra.get('metrics', {}).get('phishing_susceptibility', 'N/A')}%
- Challenge rate: {phlra.get('metrics', {}).get('challenge_rate', 'N/A')}%

Generate specific, actionable defense recommendations.
Address each major vulnerability with targeted training/controls.
Include simulation exercises to test the defenses.

Return JSON:
{DEFENSE_SCHEMA}"""

        result = self.llm.complete_json(prompt, system=DEFENSE_SYSTEM_PROMPT, max_tokens=3000)
        
        if result.get("parse_error"):
            return {"error": "Failed to parse defenses", "raw": result.get("raw")}
        
        return result
