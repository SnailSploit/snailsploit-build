"""
Vulnerability Mapper - Maps PHLRA profile to exploitable vulnerabilities.
"""

import json
from core.profile import TargetProfile
from analyzer.llm import LLMClient


VULN_SYSTEM_PROMPT = """You are mapping psychological profiles to social engineering vulnerabilities.

OUTPUT: Valid JSON only. No markdown.

VULNERABILITY CATEGORIES:

1. HUBRIS TRAPS
- Dunning-Kruger: overestimates competence
- Expert Blind Spots: dismisses "basic" attacks
- Optimism Bias: "won't happen to me"
- Self-Enhancement: ego tied to competence

2. STRESS EXPLOITATION  
- System 1 Hijacking: urgency triggers sloppy thinking
- Cognitive Tunneling: stress narrows attention
- Decision Fatigue: judgment degrades with volume
- Time Pressure Windows: quarter-end, Friday 4pm

3. TRUST/EMPATHY VECTORS
- In-group Bias: trusts perceived insiders
- Empathy Traps: helper personality
- Cultural Politeness: can't say no
- Familiarity Exploitation: name-dropping works

4. ORGANIZATIONAL DYNAMICS
- Power Distance: won't question authority
- Groupthink: won't be the one to object
- Yes-Boss Reflex: automatic compliance

5. SHAME DYNAMICS
- Face-Saving: won't admit being fooled
- Identity Threat: being wrong threatens self-concept
- Reporting Inhibition: delays disclosure

CIALDINI PRINCIPLES:
- Authority, Social Proof, Reciprocity, Liking, Scarcity, Commitment/Consistency

METRICS:
- BRS (Behavioral Risk Score): 1-100 composite
- Phishing Susceptibility: % likelihood to engage
- Challenge Rate: % likelihood to verify
- Time-to-Report: if compromised, disclosure speed"""


VULN_SCHEMA = """{
  "vulnerabilities": [
    {
      "id": "VULN-001",
      "name": "",
      "category": "hubris_trap|stress_exploitation|trust_empathy|org_dynamics|shame_dynamics",
      "severity": "critical|high|medium|low",
      "evidence": "",
      "exploitation": "",
      "phlra_dimension": ""
    }
  ],
  "cialdini_profile": {
    "authority": {"susceptibility": "high|medium|low", "attack_angle": ""},
    "social_proof": {"susceptibility": "high|medium|low", "attack_angle": ""},
    "reciprocity": {"susceptibility": "high|medium|low", "attack_angle": ""},
    "liking": {"susceptibility": "high|medium|low", "attack_angle": ""},
    "scarcity": {"susceptibility": "high|medium|low", "attack_angle": ""},
    "commitment": {"susceptibility": "high|medium|low", "attack_angle": ""},
    "primary_lever": "",
    "combination_attack": ""
  },
  "metrics": {
    "behavioral_risk_score": 0,
    "phishing_susceptibility": 0,
    "vishing_susceptibility": 0,
    "challenge_rate": 0,
    "time_to_report": "fast|standard|delayed|hidden"
  },
  "pressure_points": [],
  "attack_windows": [],
  "summary": ""
}"""


class VulnerabilityMapper:
    """Maps PHLRA analysis to specific vulnerabilities."""
    
    def __init__(self, llm: LLMClient):
        self.llm = llm
    
    def map(self, profile: TargetProfile) -> dict:
        """Map profile to vulnerabilities."""
        
        phlra = profile.phlra_scores
        
        prompt = f"""Map this PHLRA profile to exploitable vulnerabilities.

TARGET: {profile.name}
{f"Role: {profile.role}" if profile.role else ""}
{f"Company: {profile.company}" if profile.company else ""}

PHLRA ANALYSIS:
{json.dumps(phlra, indent=2)}

BEHAVIORAL DATA:
- Quotes/content samples: {json.dumps(profile.behavioral.get('quotes', [])[:5], indent=2)}
- Signals: {json.dumps(profile.behavioral.get('signals', [])[:10], indent=2)}

BREACH HISTORY:
{json.dumps(profile.breaches[:5], indent=2)}

Identify specific vulnerabilities with evidence.
Calculate realistic metrics.
Identify pressure points and optimal attack windows.

Return JSON:
{VULN_SCHEMA}"""

        result = self.llm.complete_json(prompt, system=VULN_SYSTEM_PROMPT, max_tokens=3000)
        
        if result.get("parse_error"):
            return {"error": "Failed to parse vulnerabilities", "raw": result.get("raw")}
        
        return result
