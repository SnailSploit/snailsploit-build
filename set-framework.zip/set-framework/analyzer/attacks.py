"""
Attack Designer - Designs social engineering attack scenarios.
"""

import json
from core.profile import TargetProfile
from analyzer.llm import LLMClient


ATTACK_SYSTEM_PROMPT = """You are designing social engineering attack scenarios for security assessment.

OUTPUT: Valid JSON only. No markdown.

SET TACTIC CODES:
- SET-001: Pretexting (001-01 Authority, 001-02 Urgency, 001-03 Familiarity)
- SET-004: Impersonation (004-01 Phone, 004-02 In-Person, 004-03 Email/BEC)
- SET-006: Phishing (006-01 Generic, 006-02 Spear, 006-03 Clone)
- SET-007: Vishing (007-01 Authority, 007-02 Automated)
- SET-008: Smishing
- SET-011: Advanced (011-01 Watering Hole, 011-02 BEC)
- SET-015: Deepfake (015-01 Video, 015-02 Voice)
- SET-016: AI-Enhanced (016-01 AI Spear, 016-02 Adaptive)
- SET-017: Social Media (017-01 LinkedIn, 017-02 Influencer)

PRETEXT DESIGN PRINCIPLES:
1. Leverage specific intelligence (quotes, interests, connections)
2. Match communication style of people they trust
3. Time attacks for high-stress/low-attention windows
4. Build in escalation paths
5. Include objection handlers based on personality"""


ATTACK_SCHEMA = """{
  "risk_tier": "critical|high|medium|low",
  "attack_surface_summary": "",
  "recommended_tactics": [
    {
      "rank": 1,
      "set_code": "",
      "name": "",
      "targets_vulnerability": "",
      "cialdini_lever": "",
      "success_probability": "high|medium|low",
      "effort": "low|medium|high",
      "rationale": ""
    }
  ],
  "pretexts": [
    {
      "id": "PRE-001",
      "name": "",
      "set_code": "",
      "scenario": "",
      "pretext_identity": {
        "role": "",
        "organization": "",
        "relationship": ""
      },
      "hook": "",
      "personalization": [],
      "channel": "",
      "timing": "",
      "opening_line": "",
      "key_points": [],
      "call_to_action": "",
      "urgency_mechanism": "",
      "trust_signals": [],
      "objection_handlers": {
        "if_questions_identity": "",
        "if_wants_to_verify": "",
        "if_hesitates": ""
      }
    }
  ],
  "attack_chain": {
    "objective": "",
    "stages": [
      {"stage": 1, "name": "", "action": "", "success_criteria": ""}
    ]
  },
  "playbook": {
    "rapport_builders": [],
    "trust_signals": [],
    "language_to_mirror": [],
    "topics_to_leverage": [],
    "topics_to_avoid": []
  }
}"""


class AttackDesigner:
    """Designs personalized attack scenarios."""
    
    def __init__(self, llm: LLMClient):
        self.llm = llm
    
    def design(self, profile: TargetProfile) -> dict:
        """Design attack scenarios for profile."""
        
        phlra = profile.phlra_scores
        vulns = phlra.get("vulnerabilities", [])
        cialdini = phlra.get("cialdini_profile", {})
        
        prompt = f"""Design personalized social engineering attack scenarios.

TARGET: {profile.name}
{f"Role: {profile.role}" if profile.role else ""}
{f"Company: {profile.company}" if profile.company else ""}

VULNERABILITIES:
{json.dumps(vulns[:5], indent=2)}

CIALDINI PROFILE:
{json.dumps(cialdini, indent=2)}

PHLRA SUMMARY:
- Psychological: {phlra.get('psychological', {}).get('summary', 'N/A')}
- Hierarchical: {phlra.get('hierarchical', {}).get('summary', 'N/A')}
- Relational: {phlra.get('relational', {}).get('summary', 'N/A')}

PERSONALIZATION DATA:
- Accounts: {[a['platform'] for a in profile.accounts]}
- Quotes: {json.dumps(profile.behavioral.get('quotes', [])[:3], indent=2)}
- Trust anchors: {phlra.get('relational', {}).get('trust_anchors', [])}
- In-groups: {phlra.get('relational', {}).get('in_groups', [])}

Design highly personalized attack scenarios using this intelligence.
Include specific pretexts with opening lines and objection handlers.

Return JSON:
{ATTACK_SCHEMA}"""

        result = self.llm.complete_json(prompt, system=ATTACK_SYSTEM_PROMPT, max_tokens=4000)
        
        if result.get("parse_error"):
            return {"error": "Failed to parse attacks", "raw": result.get("raw")}
        
        return result
