"""
Analysis modules for SET Framework.
"""

from analyzer.llm import LLMClient
from analyzer.phlra import PHLRAAnalyzer
from analyzer.vulnerabilities import VulnerabilityMapper
from analyzer.attacks import AttackDesigner
from analyzer.defenses import DefenseAdvisor
