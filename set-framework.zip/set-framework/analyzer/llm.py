"""
LLM client abstraction.
Supports Claude API and Ollama for local inference.
"""

import json
import re
from typing import Optional
import os


class LLMClient:
    """Unified interface for LLM providers."""
    
    def __init__(self, config: dict):
        self.provider = config.get("provider", "claude")
        self.model = config.get("model", "claude-sonnet-4-20250514")
        self.api_key = config.get("api_key", "")
        self.endpoint = config.get("endpoint", "")
        
        if self.provider == "claude" and not self.api_key:
            self.api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    
    def complete(self, prompt: str, system: str = None, max_tokens: int = 4000) -> str:
        """Generate completion."""
        if self.provider == "claude":
            return self._claude_complete(prompt, system, max_tokens)
        elif self.provider == "ollama":
            return self._ollama_complete(prompt, system, max_tokens)
        else:
            raise ValueError(f"Unknown provider: {self.provider}")
    
    def _claude_complete(self, prompt: str, system: str = None, max_tokens: int = 4000) -> str:
        """Call Claude API."""
        import requests
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01"
        }
        
        body = {
            "model": self.model,
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}]
        }
        
        if system:
            body["system"] = system
        
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers=headers,
            json=body,
            timeout=120
        )
        
        if resp.status_code != 200:
            raise RuntimeError(f"Claude API error: {resp.status_code} - {resp.text}")
        
        data = resp.json()
        return data["content"][0]["text"]
    
    def _ollama_complete(self, prompt: str, system: str = None, max_tokens: int = 4000) -> str:
        """Call Ollama API."""
        import requests
        
        endpoint = self.endpoint or "http://localhost:11434"
        
        body = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_predict": max_tokens
            }
        }
        
        if system:
            body["system"] = system
        
        resp = requests.post(
            f"{endpoint}/api/generate",
            json=body,
            timeout=300
        )
        
        if resp.status_code != 200:
            raise RuntimeError(f"Ollama error: {resp.status_code} - {resp.text}")
        
        data = resp.json()
        return data.get("response", "")
    
    def complete_json(self, prompt: str, system: str = None, max_tokens: int = 4000) -> dict:
        """Generate completion and parse as JSON."""
        response = self.complete(prompt, system, max_tokens)
        
        # Try to extract JSON from response
        json_match = re.search(r'\{[\s\S]*\}', response)
        if json_match:
            try:
                return json.loads(json_match.group())
            except json.JSONDecodeError:
                pass
        
        # Try parsing entire response
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            return {"raw": response, "parse_error": True}
