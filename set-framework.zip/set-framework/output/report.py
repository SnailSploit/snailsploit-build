"""
Report Generator - Multiple output formats.
"""

import json
from datetime import datetime
from typing import Optional

from core.profile import TargetProfile


class ReportGenerator:
    """Generates reports in various formats."""
    
    def __init__(self, profile: TargetProfile):
        self.profile = profile
        self.generated_at = datetime.now()
    
    def to_json(self) -> str:
        """Export full profile as JSON."""
        return json.dumps(self.profile.to_dict(), indent=2, default=str)
    
    def to_markdown(self) -> str:
        """Generate Markdown report."""
        p = self.profile
        phlra = p.phlra_scores
        
        md = f"""# Social Engineering Assessment Report
## Target: {p.name}

**Generated:** {self.generated_at.strftime('%Y-%m-%d %H:%M')}  
**Company:** {p.company or 'N/A'}  
**Role:** {p.role or 'N/A'}  

---

## Executive Summary

**Behavioral Risk Score:** {phlra.get('behavioral_risk_score', 'N/A')}  
**Risk Tier:** {phlra.get('attacks', {}).get('risk_tier', 'N/A')}  
**Data Quality:** {phlra.get('data_quality', 'N/A')}  

{phlra.get('overall_summary', '')}

---

## PHLRA Analysis

### Psychological (P)
**Score:** {phlra.get('psychological', {}).get('score', 'N/A')}/10  
**Confidence:** {phlra.get('psychological', {}).get('confidence', 'N/A')}

{phlra.get('psychological', {}).get('summary', 'No data')}

**Hubris Level:** {phlra.get('psychological', {}).get('hubris_level', 'N/A')}  
**Cognitive Biases Identified:**
"""
        for bias in phlra.get('psychological', {}).get('cognitive_biases', [])[:5]:
            md += f"- {bias.get('bias', 'Unknown')}: {bias.get('evidence', '')}\n"

        md += f"""
### Hierarchical (H)
**Score:** {phlra.get('hierarchical', {}).get('score', 'N/A')}/10  
**Seniority:** {phlra.get('hierarchical', {}).get('seniority', 'N/A')}  
**Authority Compliance:** {phlra.get('hierarchical', {}).get('authority_compliance', 'N/A')}

{phlra.get('hierarchical', {}).get('summary', 'No data')}

### Logical (L)
**Score:** {phlra.get('logical', {}).get('score', 'N/A')}/10  
**Digital Footprint:** {phlra.get('logical', {}).get('digital_footprint', 'N/A')}  
**Technical Sophistication:** {phlra.get('logical', {}).get('technical_sophistication', 'N/A')}  
**OPSEC Awareness:** {phlra.get('logical', {}).get('opsec_awareness', 'N/A')}

{phlra.get('logical', {}).get('summary', 'No data')}

### Relational (R)
**Score:** {phlra.get('relational', {}).get('score', 'N/A')}/10

{phlra.get('relational', {}).get('summary', 'No data')}

**Trust Anchors:** {', '.join(phlra.get('relational', {}).get('trust_anchors', [])) or 'N/A'}  
**In-Groups:** {', '.join(phlra.get('relational', {}).get('in_groups', [])) or 'N/A'}

### Asset-Based (A)
**Score:** {phlra.get('asset_based', {}).get('score', 'N/A')}/10  
**Target Value:** {phlra.get('asset_based', {}).get('target_value', 'N/A')}  
**Lateral Movement Potential:** {phlra.get('asset_based', {}).get('lateral_potential', 'N/A')}

{phlra.get('asset_based', {}).get('summary', 'No data')}

---

## Vulnerabilities

| Severity | Vulnerability | Category | Evidence |
|----------|--------------|----------|----------|
"""
        for v in phlra.get('vulnerabilities', [])[:10]:
            md += f"| {v.get('severity', '?')} | {v.get('name', 'Unknown')} | {v.get('category', '?')} | {v.get('evidence', '')[:50]}... |\n"

        md += f"""
---

## Cialdini Influence Profile

| Principle | Susceptibility | Attack Angle |
|-----------|---------------|--------------|
"""
        cialdini = phlra.get('cialdini_profile', {})
        for principle in ['authority', 'social_proof', 'reciprocity', 'liking', 'scarcity', 'commitment']:
            data = cialdini.get(principle, {})
            if isinstance(data, dict):
                md += f"| {principle.title()} | {data.get('susceptibility', 'N/A')} | {data.get('attack_angle', 'N/A')[:40]}... |\n"

        md += f"""
**Primary Lever:** {cialdini.get('primary_lever', 'N/A')}

---

## Risk Metrics

- **Behavioral Risk Score:** {phlra.get('metrics', {}).get('behavioral_risk_score', 'N/A')}
- **Phishing Susceptibility:** {phlra.get('metrics', {}).get('phishing_susceptibility', 'N/A')}%
- **Vishing Susceptibility:** {phlra.get('metrics', {}).get('vishing_susceptibility', 'N/A')}%
- **Challenge Rate:** {phlra.get('metrics', {}).get('challenge_rate', 'N/A')}%
- **Time to Report:** {phlra.get('metrics', {}).get('time_to_report', 'N/A')}

---

## Recommended Attack Vectors

"""
        attacks = phlra.get('attacks', {})
        for i, tactic in enumerate(attacks.get('recommended_tactics', [])[:5], 1):
            md += f"""### {i}. {tactic.get('name', 'Unknown')} ({tactic.get('set_code', '?')})
- **Success Probability:** {tactic.get('success_probability', 'N/A')}
- **Targets:** {tactic.get('targets_vulnerability', 'N/A')}
- **Cialdini Lever:** {tactic.get('cialdini_lever', 'N/A')}
- **Rationale:** {tactic.get('rationale', 'N/A')}

"""

        md += """---

## Defense Recommendations

### Quick Wins
"""
        defenses = phlra.get('defenses', {})
        for qw in defenses.get('quick_wins', [])[:5]:
            md += f"- {qw}\n"

        md += """
### Training Recommendations
"""
        for t in defenses.get('training', [])[:5]:
            md += f"- **{t.get('topic', 'Unknown')}** ({t.get('priority', 'N/A')}): {t.get('addresses_vulnerability', 'N/A')}\n"

        md += """
### Simulation Exercises
"""
        for s in defenses.get('simulations', [])[:3]:
            md += f"- [{s.get('set_code', '?')}] {s.get('scenario', 'N/A')} (Difficulty: {s.get('difficulty', 'N/A')})\n"

        md += """
### Long-term Improvements
"""
        for lt in defenses.get('long_term', [])[:5]:
            md += f"- {lt}\n"

        md += f"""
---

## Data Collection Summary

- **Accounts Found:** {len(p.accounts)}
- **Content Items:** {len(p.content)}
- **Behavioral Signals:** {len(p.behavioral.get('signals', []))}
- **Breaches:** {len(p.breaches)}
- **Tool Runs:** {len(p.history)}
- **Total Findings:** {len(p.findings)}

### Platforms Discovered
"""
        platforms = list(set(a['platform'] for a in p.accounts))
        for platform in sorted(platforms):
            md += f"- {platform}\n"

        md += f"""
---

*Report generated by SET Framework*  
*Assessment Date: {self.generated_at.strftime('%Y-%m-%d')}*
"""
        return md
    
    def to_html(self) -> str:
        """Generate HTML report."""
        md = self.to_markdown()
        
        # Basic markdown to HTML conversion
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>SET Assessment - {self.profile.name}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: #1a1a2e; color: #eee; }}
        h1, h2, h3 {{ color: #4da6ff; }}
        table {{ border-collapse: collapse; width: 100%; margin: 1em 0; }}
        th, td {{ border: 1px solid #333; padding: 8px; text-align: left; }}
        th {{ background: #16213e; }}
        tr:nth-child(even) {{ background: #0f0f23; }}
        code {{ background: #16213e; padding: 2px 6px; border-radius: 3px; }}
        hr {{ border: none; border-top: 1px solid #333; margin: 2em 0; }}
        .critical {{ color: #ff4757; }}
        .high {{ color: #ffa502; }}
        .medium {{ color: #ffdd59; }}
        .low {{ color: #2ed573; }}
    </style>
</head>
<body>
"""
        # Simple markdown conversion
        import re
        content = md
        content = re.sub(r'^# (.+)$', r'<h1>\1</h1>', content, flags=re.MULTILINE)
        content = re.sub(r'^## (.+)$', r'<h2>\1</h2>', content, flags=re.MULTILINE)
        content = re.sub(r'^### (.+)$', r'<h3>\1</h3>', content, flags=re.MULTILINE)
        content = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', content)
        content = re.sub(r'^- (.+)$', r'<li>\1</li>', content, flags=re.MULTILINE)
        content = re.sub(r'(<li>.*</li>\n)+', r'<ul>\g<0></ul>', content)
        content = re.sub(r'^---$', r'<hr>', content, flags=re.MULTILINE)
        content = content.replace('\n\n', '</p><p>')
        content = f'<p>{content}</p>'
        
        html += content
        html += """
</body>
</html>"""
        return html
    
    def to_pdf(self) -> bytes:
        """Generate PDF report."""
        try:
            from weasyprint import HTML
            html = self.to_html()
            return HTML(string=html).write_pdf()
        except ImportError:
            # Fallback: return HTML with note
            html = self.to_html()
            html = html.replace('</body>', '<p><em>PDF generation requires weasyprint. Install with: pip install weasyprint</em></p></body>')
            return html.encode('utf-8')
