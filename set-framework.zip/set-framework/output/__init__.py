"""
Output generation for SET Framework.
"""

from output.report import ReportGenerator
