"""
Core data models for SET Framework.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum
import json


class PHLRADimension(Enum):
    PSYCHOLOGICAL = "P"
    HIERARCHICAL = "H"
    LOGICAL = "L"
    RELATIONAL = "R"
    ASSET = "A"


@dataclass
class Finding:
    """A single piece of intelligence from a tool."""
    source: str                          # Tool name
    category: str                        # account, email, profile, content, breach, etc.
    platform: Optional[str]              # linkedin, twitter, github, etc.
    data: Dict[str, Any]                 # The actual finding data
    confidence: float = 0.8              # 0-1 confidence score
    phlra_relevant: List[str] = field(default_factory=list)  # ["P", "R"] etc.
    timestamp: datetime = field(default_factory=datetime.now)
    raw: Optional[str] = None            # Raw output for debugging
    
    def to_dict(self) -> dict:
        return {
            "source": self.source,
            "category": self.category,
            "platform": self.platform,
            "data": self.data,
            "confidence": self.confidence,
            "phlra_relevant": self.phlra_relevant,
            "timestamp": self.timestamp.isoformat(),
            "raw": self.raw
        }
    
    @classmethod
    def from_dict(cls, d: dict) -> "Finding":
        d = d.copy()
        if "timestamp" in d and isinstance(d["timestamp"], str):
            d["timestamp"] = datetime.fromisoformat(d["timestamp"])
        return cls(**d)


@dataclass
class ToolRun:
    """Record of a tool execution."""
    tool: str
    input_type: str
    input_value: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    success: bool = False
    findings_count: int = 0
    error: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "tool": self.tool,
            "input_type": self.input_type,
            "input_value": self.input_value,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "success": self.success,
            "findings_count": self.findings_count,
            "error": self.error
        }


class TargetProfile:
    """
    Accumulated intelligence about a target.
    Updated iteratively as tools discover new information.
    """
    
    def __init__(
        self,
        name: str,
        email: Optional[str] = None,
        company: Optional[str] = None,
        role: Optional[str] = None,
        linkedin: Optional[str] = None,
        twitter: Optional[str] = None,
        github: Optional[str] = None,
        domain: Optional[str] = None
    ):
        # Seed identifiers
        self.name = name
        self.company = company
        self.role = role
        self.domain = domain
        
        # Discovered identifiers
        self.identifiers = {
            "emails": [email] if email else [],
            "usernames": [],
            "phones": [],
            "linkedin": linkedin,
            "twitter": twitter,
            "github": github,
            "other_handles": {}
        }
        
        # Discovered accounts (confirmed platform presence)
        self.accounts: List[Dict] = []
        
        # Content (posts, articles, quotes, etc.)
        self.content: List[Dict] = []
        
        # Network/relationships
        self.network: List[Dict] = []
        
        # Breach data
        self.breaches: List[Dict] = []
        
        # Extracted behavioral signals
        self.behavioral: Dict = {
            "signals": [],
            "communication_style": None,
            "expertise_claims": [],
            "opinions": [],
            "hubris_indicators": [],
            "trust_anchors": [],
            "triggers": [],
            "quotes": []
        }
        
        # PHLRA scores (updated as we learn more)
        self.phlra_scores: Dict = {
            "psychological": {"score": 0, "confidence": 0, "signals": []},
            "hierarchical": {"score": 0, "confidence": 0, "signals": []},
            "logical": {"score": 0, "confidence": 0, "signals": []},
            "relational": {"score": 0, "confidence": 0, "signals": []},
            "asset_based": {"score": 0, "confidence": 0, "signals": []},
            "overall_confidence": 0,
            "behavioral_risk_score": 0,
            "vulnerabilities": [],
            "attacks": [],
            "defenses": []
        }
        
        # Gaps - what we still need to know
        self.gaps: List[str] = []
        
        # Tool run history
        self.history: List[ToolRun] = []
        
        # All findings (raw)
        self.findings: List[Finding] = []
        
        # Metadata
        self.created_at = datetime.now()
        self.updated_at = datetime.now()
        self.iterations = 0
    
    def add_finding(self, finding: Finding):
        """Add a finding and update relevant profile sections."""
        self.findings.append(finding)
        self.updated_at = datetime.now()
        
        # Route finding to appropriate section
        if finding.category == "account":
            self._add_account(finding)
        elif finding.category == "email":
            self._add_email(finding)
        elif finding.category == "username":
            self._add_username(finding)
        elif finding.category == "content":
            self._add_content(finding)
        elif finding.category == "profile":
            self._add_profile_data(finding)
        elif finding.category == "network":
            self._add_network(finding)
        elif finding.category == "breach":
            self._add_breach(finding)
        elif finding.category == "behavioral":
            self._add_behavioral(finding)
    
    def _add_account(self, finding: Finding):
        """Add discovered account."""
        account = {
            "platform": finding.platform,
            "url": finding.data.get("url"),
            "username": finding.data.get("username"),
            "exists": finding.data.get("exists", True),
            "source": finding.source,
            "confidence": finding.confidence
        }
        # Dedupe
        if not any(a["platform"] == account["platform"] and a["url"] == account["url"] for a in self.accounts):
            self.accounts.append(account)
    
    def _add_email(self, finding: Finding):
        """Add discovered email."""
        email = finding.data.get("email")
        if email and email not in self.identifiers["emails"]:
            self.identifiers["emails"].append(email)
    
    def _add_username(self, finding: Finding):
        """Add discovered username."""
        username = finding.data.get("username")
        if username and username not in self.identifiers["usernames"]:
            self.identifiers["usernames"].append(username)
        
        # Also update platform-specific handles
        platform = finding.platform
        if platform and username:
            if platform == "linkedin":
                self.identifiers["linkedin"] = self.identifiers["linkedin"] or username
            elif platform in ["twitter", "x"]:
                self.identifiers["twitter"] = self.identifiers["twitter"] or username
            elif platform == "github":
                self.identifiers["github"] = self.identifiers["github"] or username
            else:
                self.identifiers["other_handles"][platform] = username
    
    def _add_content(self, finding: Finding):
        """Add discovered content (posts, articles, etc.)."""
        content = {
            "platform": finding.platform,
            "type": finding.data.get("type", "post"),
            "text": finding.data.get("text"),
            "url": finding.data.get("url"),
            "date": finding.data.get("date"),
            "engagement": finding.data.get("engagement", {}),
            "source": finding.source
        }
        self.content.append(content)
        
        # Extract behavioral signals from content
        if finding.data.get("text"):
            self.behavioral["quotes"].append({
                "text": finding.data["text"][:500],  # Truncate long content
                "platform": finding.platform,
                "source": finding.source
            })
    
    def _add_profile_data(self, finding: Finding):
        """Update profile data from platform profile."""
        data = finding.data
        
        # Update basic info if more complete
        if data.get("name") and not self.name:
            self.name = data["name"]
        if data.get("company") and not self.company:
            self.company = data["company"]
        if data.get("role") and not self.role:
            self.role = data["role"]
        
        # Store full profile in account
        self._add_account(Finding(
            source=finding.source,
            category="account",
            platform=finding.platform,
            data=data,
            confidence=finding.confidence
        ))
    
    def _add_network(self, finding: Finding):
        """Add network/relationship data."""
        self.network.append({
            "type": finding.data.get("type", "connection"),
            "platform": finding.platform,
            "data": finding.data,
            "source": finding.source
        })
    
    def _add_breach(self, finding: Finding):
        """Add breach data."""
        self.breaches.append({
            "breach_name": finding.data.get("name"),
            "date": finding.data.get("date"),
            "data_types": finding.data.get("data_types", []),
            "source": finding.source
        })
    
    def _add_behavioral(self, finding: Finding):
        """Add behavioral signal."""
        self.behavioral["signals"].append({
            "type": finding.data.get("type"),
            "signal": finding.data.get("signal"),
            "evidence": finding.data.get("evidence"),
            "phlra": finding.phlra_relevant,
            "source": finding.source
        })
    
    def record_tool_run(self, run: ToolRun):
        """Record a tool execution."""
        self.history.append(run)
    
    def get_all_identifiers(self) -> Dict[str, List[str]]:
        """Get all known identifiers for tool input."""
        return {
            "email": self.identifiers["emails"],
            "username": self.identifiers["usernames"] + [
                h for h in [
                    self.identifiers["linkedin"],
                    self.identifiers["twitter"],
                    self.identifiers["github"]
                ] if h
            ],
            "name": [self.name] if self.name else [],
            "domain": [self.domain] if self.domain else [],
            "phone": self.identifiers["phones"]
        }
    
    def get_untried_identifiers(self, tool_name: str, input_type: str) -> List[str]:
        """Get identifiers not yet tried with this tool."""
        tried = set()
        for run in self.history:
            if run.tool == tool_name and run.input_type == input_type:
                tried.add(run.input_value)
        
        all_ids = self.get_all_identifiers().get(input_type, [])
        return [i for i in all_ids if i and i not in tried]
    
    def get_platform_accounts(self, platform: str) -> List[Dict]:
        """Get all accounts for a specific platform."""
        return [a for a in self.accounts if a["platform"] == platform]
    
    def has_platform(self, platform: str) -> bool:
        """Check if we have confirmed account on platform."""
        return any(a["platform"] == platform and a.get("exists", True) for a in self.accounts)
    
    def calculate_completeness(self) -> float:
        """Calculate profile completeness score (0-1)."""
        scores = []
        
        # Basic info
        scores.append(1.0 if self.name else 0)
        scores.append(1.0 if self.company else 0)
        scores.append(1.0 if self.role else 0)
        scores.append(min(len(self.identifiers["emails"]) / 2, 1.0))
        
        # Accounts (want at least 3 platforms)
        scores.append(min(len(self.accounts) / 3, 1.0))
        
        # Content (want at least 10 items)
        scores.append(min(len(self.content) / 10, 1.0))
        
        # Behavioral signals
        scores.append(min(len(self.behavioral["signals"]) / 5, 1.0))
        scores.append(min(len(self.behavioral["quotes"]) / 5, 1.0))
        
        return sum(scores) / len(scores)
    
    def is_saturated(self, threshold: float = 0.8) -> bool:
        """Check if profile is sufficiently complete."""
        return self.calculate_completeness() >= threshold
    
    def to_dict(self) -> dict:
        """Serialize profile to dictionary."""
        return {
            "name": self.name,
            "company": self.company,
            "role": self.role,
            "domain": self.domain,
            "identifiers": self.identifiers,
            "accounts": self.accounts,
            "content": self.content,
            "network": self.network,
            "breaches": self.breaches,
            "behavioral": self.behavioral,
            "phlra_scores": self.phlra_scores,
            "gaps": self.gaps,
            "history": [h.to_dict() for h in self.history],
            "findings": [f.to_dict() for f in self.findings],
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "iterations": self.iterations,
            "completeness": self.calculate_completeness()
        }
    
    @classmethod
    def from_dict(cls, d: dict) -> "TargetProfile":
        """Deserialize profile from dictionary."""
        profile = cls(
            name=d.get("name", ""),
            company=d.get("company"),
            role=d.get("role"),
            domain=d.get("domain")
        )
        
        profile.identifiers = d.get("identifiers", profile.identifiers)
        profile.accounts = d.get("accounts", [])
        profile.content = d.get("content", [])
        profile.network = d.get("network", [])
        profile.breaches = d.get("breaches", [])
        profile.behavioral = d.get("behavioral", profile.behavioral)
        profile.phlra_scores = d.get("phlra_scores", profile.phlra_scores)
        profile.gaps = d.get("gaps", [])
        profile.iterations = d.get("iterations", 0)
        
        # Reconstruct findings
        for f in d.get("findings", []):
            profile.findings.append(Finding.from_dict(f))
        
        if d.get("created_at"):
            profile.created_at = datetime.fromisoformat(d["created_at"])
        if d.get("updated_at"):
            profile.updated_at = datetime.fromisoformat(d["updated_at"])
        
        return profile
    
    def __repr__(self):
        return f"<TargetProfile: {self.name} | {len(self.accounts)} accounts | {len(self.findings)} findings | {self.calculate_completeness():.0%} complete>"
