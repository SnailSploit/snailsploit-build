"""
Agentic discovery loop - the brain of SET Framework.

The loop:
1. Analyzes current profile state
2. Identifies gaps in knowledge
3. Selects appropriate tools to fill gaps
4. Runs tools and collects findings
5. Updates profile with new findings
6. Recalculates PHLRA scores
7. Repeats until saturated or max iterations
"""

import time
from datetime import datetime
from typing import Optional, List, Dict, Tuple
import json

from core.profile import TargetProfile, Finding, ToolRun
from analyzer.llm import LLMClient
from tools import get_tool, AVAILABLE_TOOLS


class AgentLoop:
    """
    Orchestrates the iterative discovery process.
    LLM decides what to do next based on profile state.
    """
    
    def __init__(
        self,
        profile: TargetProfile,
        llm: LLMClient,
        config: dict,
        verbose: bool = False,
        max_iterations: int = 10
    ):
        self.profile = profile
        self.llm = llm
        self.config = config
        self.verbose = verbose
        self.max_iterations = max_iterations
        
        # Load enabled tools
        self.enabled_tools = config.get("tools", {}).get("enabled", [])
        self.tool_timeout = config.get("tools", {}).get("timeout", 120)
        
        # Loop state
        self.iteration = 0
        self.saturation_threshold = config.get("loop", {}).get("saturation_threshold", 0.8)
    
    def log(self, msg: str, level: str = "info"):
        """Log message if verbose."""
        icons = {"info": "[*]", "success": "[+]", "error": "[!]", "warn": "[?]"}
        if self.verbose or level in ["error", "success"]:
            print(f"{icons.get(level, '[*]')} {msg}")
    
    def run(self) -> TargetProfile:
        """Run the discovery loop until saturated or max iterations."""
        self.log(f"Starting discovery loop (max {self.max_iterations} iterations)")
        self.log(f"Enabled tools: {', '.join(self.enabled_tools)}")
        
        while self.iteration < self.max_iterations:
            self.iteration += 1
            self.profile.iterations = self.iteration
            
            completeness = self.profile.calculate_completeness()
            self.log(f"\n--- Iteration {self.iteration} | Completeness: {completeness:.0%} ---")
            
            # Check saturation
            if self.profile.is_saturated(self.saturation_threshold):
                self.log("Profile saturated, stopping discovery", "success")
                break
            
            # Get LLM recommendation for next action
            next_action = self._get_next_action()
            
            if not next_action or next_action.get("action") == "stop":
                self.log("LLM recommends stopping", "info")
                break
            
            # Execute the recommended tool
            tool_name = next_action.get("tool")
            input_type = next_action.get("input_type")
            input_value = next_action.get("input_value")
            
            if tool_name and input_value:
                self._run_tool(tool_name, input_type, input_value)
            else:
                self.log(f"Invalid action recommendation: {next_action}", "warn")
                # Try a fallback strategy
                self._run_fallback()
        
        self.log(f"\nDiscovery complete after {self.iteration} iterations")
        self.log(f"Final completeness: {self.profile.calculate_completeness():.0%}")
        
        return self.profile
    
    def _get_next_action(self) -> Optional[Dict]:
        """Ask LLM what tool to run next."""
        
        # Build context for LLM
        context = {
            "target": {
                "name": self.profile.name,
                "company": self.profile.company,
                "role": self.profile.role
            },
            "known_identifiers": self.profile.get_all_identifiers(),
            "accounts_found": [
                {"platform": a["platform"], "username": a.get("username")}
                for a in self.profile.accounts
            ],
            "content_count": len(self.profile.content),
            "behavioral_signals_count": len(self.profile.behavioral["signals"]),
            "breaches_found": len(self.profile.breaches),
            "completeness": self.profile.calculate_completeness(),
            "iteration": self.iteration,
            "max_iterations": self.max_iterations,
            "tools_run": [
                {"tool": h.tool, "input": h.input_value, "success": h.success}
                for h in self.profile.history[-10:]  # Last 10 runs
            ]
        }
        
        # Available tools with their input types
        available = []
        for tool_name in self.enabled_tools:
            tool = get_tool(tool_name)
            if tool and tool.is_available():
                # Get untried inputs for this tool
                for input_type in tool.input_types:
                    untried = self.profile.get_untried_identifiers(tool_name, input_type)
                    if untried:
                        available.append({
                            "tool": tool_name,
                            "input_type": input_type,
                            "untried_inputs": untried[:3],  # Show first 3
                            "description": tool.description
                        })
        
        if not available:
            self.log("No more tool/input combinations to try", "warn")
            return {"action": "stop", "reason": "exhausted"}
        
        context["available_tools"] = available
        
        # Ask LLM
        prompt = f"""You are orchestrating an OSINT investigation. Based on the current state, decide what tool to run next.

CURRENT STATE:
{json.dumps(context, indent=2)}

GOAL: Build a comprehensive profile for social engineering assessment. We need:
- Multiple platform accounts (LinkedIn, Twitter, GitHub, etc.)
- Content they've posted (for behavioral analysis)
- Breach history (security awareness indicator)
- Network connections (trust anchors)

AVAILABLE TOOLS TO RUN:
{json.dumps(available, indent=2)}

RULES:
1. Prioritize tools that fill the biggest gaps
2. Don't repeat failed tool/input combinations
3. Username enumeration tools (sherlock, maigret) are great for finding accounts
4. Email-based tools (holehe, hibp) reveal account existence and breaches
5. GitHub API gives technical profile and communication style
6. Stop if we have enough data or are spinning wheels

Respond with JSON only:
{{
    "action": "run_tool" or "stop",
    "tool": "tool_name",
    "input_type": "email" or "username" or "name" or "domain",
    "input_value": "the actual value to use",
    "reasoning": "brief explanation"
}}"""

        try:
            response = self.llm.complete(prompt, max_tokens=500)
            
            # Parse JSON from response
            import re
            json_match = re.search(r'\{[\s\S]*\}', response)
            if json_match:
                action = json.loads(json_match.group())
                self.log(f"LLM recommends: {action.get('tool')} with {action.get('input_value')} ({action.get('reasoning', '')})")
                return action
        except Exception as e:
            self.log(f"LLM decision error: {e}", "error")
        
        return None
    
    def _run_tool(self, tool_name: str, input_type: str, input_value: str):
        """Execute a tool and process results."""
        tool = get_tool(tool_name)
        if not tool:
            self.log(f"Tool not found: {tool_name}", "error")
            return
        
        self.log(f"Running {tool_name} with {input_type}={input_value}")
        
        # Record the run
        run = ToolRun(
            tool=tool_name,
            input_type=input_type,
            input_value=input_value,
            started_at=datetime.now()
        )
        
        try:
            # Execute tool with timeout
            findings = tool.run(input_value, input_type, timeout=self.tool_timeout)
            
            run.completed_at = datetime.now()
            run.success = True
            run.findings_count = len(findings)
            
            self.log(f"  Found {len(findings)} results", "success")
            
            # Add findings to profile
            for finding in findings:
                self.profile.add_finding(finding)
                if self.verbose:
                    self.log(f"    + [{finding.category}] {finding.platform}: {list(finding.data.keys())}")
        
        except Exception as e:
            run.completed_at = datetime.now()
            run.success = False
            run.error = str(e)
            self.log(f"  Tool error: {e}", "error")
        
        self.profile.record_tool_run(run)
    
    def _run_fallback(self):
        """Run a sensible tool when LLM fails to decide."""
        # Priority: username enum → email check → breach check
        
        identifiers = self.profile.get_all_identifiers()
        
        # Try sherlock with usernames
        if identifiers["username"]:
            for username in identifiers["username"]:
                if self.profile.get_untried_identifiers("sherlock", "username"):
                    self._run_tool("sherlock", "username", username)
                    return
        
        # Try holehe with emails
        if identifiers["email"]:
            for email in identifiers["email"]:
                if self.profile.get_untried_identifiers("holehe", "email"):
                    self._run_tool("holehe", "email", email)
                    return
        
        # Try hibp with emails
        if identifiers["email"]:
            for email in identifiers["email"]:
                if self.profile.get_untried_identifiers("hibp", "email"):
                    self._run_tool("hibp", "email", email)
                    return
        
        self.log("Fallback: no viable tool/input combinations", "warn")
    
    def run_analysis(self) -> TargetProfile:
        """Run PHLRA analysis on the collected data."""
        from analyzer.phlra import PHLRAAnalyzer
        from analyzer.vulnerabilities import VulnerabilityMapper
        from analyzer.attacks import AttackDesigner
        from analyzer.defenses import DefenseAdvisor
        
        self.log("\n=== Running Analysis Pipeline ===")
        
        # PHLRA Analysis
        self.log("Running PHLRA analysis...")
        phlra = PHLRAAnalyzer(self.llm)
        phlra_results = phlra.analyze(self.profile)
        self.profile.phlra_scores.update(phlra_results)
        
        # Vulnerability Mapping
        self.log("Mapping vulnerabilities...")
        vuln_mapper = VulnerabilityMapper(self.llm)
        vulns = vuln_mapper.map(self.profile)
        self.profile.phlra_scores["vulnerabilities"] = vulns.get("vulnerabilities", [])
        self.profile.phlra_scores["cialdini_profile"] = vulns.get("cialdini_profile", {})
        self.profile.phlra_scores["metrics"] = vulns.get("metrics", {})
        self.profile.phlra_scores["behavioral_risk_score"] = vulns.get("metrics", {}).get("behavioral_risk_score", 0)
        
        # Attack Design
        self.log("Designing attack scenarios...")
        attack_designer = AttackDesigner(self.llm)
        attacks = attack_designer.design(self.profile)
        self.profile.phlra_scores["attacks"] = attacks
        
        # Defense Recommendations
        self.log("Generating defense recommendations...")
        defense_advisor = DefenseAdvisor(self.llm)
        defenses = defense_advisor.recommend(self.profile)
        self.profile.phlra_scores["defenses"] = defenses
        
        self.log("Analysis complete", "success")
        
        return self.profile
