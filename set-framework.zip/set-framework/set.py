#!/usr/bin/env python3
"""
SET Framework - Social Engineering Toolkit for Assessment
Agentic OSINT harvesting + PHLRA analysis

Usage:
    python set.py run --target "John Doe" --email john@company.com
    python set.py run --target "John Doe" --linkedin "linkedin.com/in/johndoe"
    python set.py analyze --profile data/profiles/john-doe.json
    python set.py report --profile data/profiles/john-doe.json --format pdf
"""

import click
import yaml
import json
import os
from pathlib import Path
from datetime import datetime

from core.loop import AgentLoop
from core.profile import TargetProfile
from analyzer.llm import LLMClient
from output.report import ReportGenerator


def load_config(config_path: str = "config.yaml") -> dict:
    """Load configuration from YAML file."""
    if not os.path.exists(config_path):
        click.echo(f"[!] Config not found at {config_path}, using defaults")
        return get_default_config()
    
    with open(config_path) as f:
        config = yaml.safe_load(f)
    
    # Expand environment variables
    config = expand_env_vars(config)
    return config


def expand_env_vars(obj):
    """Recursively expand ${VAR} in config values."""
    if isinstance(obj, str):
        if obj.startswith("${") and obj.endswith("}"):
            var_name = obj[2:-1]
            return os.environ.get(var_name, "")
        return obj
    elif isinstance(obj, dict):
        return {k: expand_env_vars(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [expand_env_vars(item) for item in obj]
    return obj


def get_default_config() -> dict:
    """Return default configuration."""
    return {
        "llm": {
            "provider": "claude",
            "model": "claude-sonnet-4-20250514",
            "api_key": os.environ.get("ANTHROPIC_API_KEY", "")
        },
        "tools": {
            "enabled": ["sherlock", "maigret", "holehe", "github", "hibp"],
            "timeout": 120,
            "paths": {}
        },
        "loop": {
            "max_iterations": 10,
            "saturation_threshold": 0.8,
            "min_confidence": 0.6
        },
        "output": {
            "dir": "./data/reports",
            "save_intermediates": True
        }
    }


@click.group()
@click.option("--config", "-c", default="config.yaml", help="Config file path")
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
@click.pass_context
def cli(ctx, config, verbose):
    """SET Framework - Social Engineering Assessment Tool"""
    ctx.ensure_object(dict)
    ctx.obj["config"] = load_config(config)
    ctx.obj["verbose"] = verbose


@cli.command()
@click.option("--target", "-t", required=True, help="Target full name")
@click.option("--email", "-e", help="Known email address")
@click.option("--company", "-c", help="Company name")
@click.option("--role", "-r", help="Job role/title")
@click.option("--linkedin", help="LinkedIn URL or username")
@click.option("--twitter", help="Twitter/X handle")
@click.option("--github", help="GitHub username")
@click.option("--domain", "-d", help="Company domain for email harvesting")
@click.option("--output", "-o", help="Output file path")
@click.option("--max-iterations", default=10, help="Max discovery loop iterations")
@click.pass_context
def run(ctx, target, email, company, role, linkedin, twitter, github, domain, output, max_iterations):
    """Run full assessment - harvest + analyze."""
    config = ctx.obj["config"]
    verbose = ctx.obj["verbose"]
    
    click.echo(f"\n{'='*60}")
    click.echo(f"  SET Framework - Social Engineering Assessment")
    click.echo(f"{'='*60}")
    click.echo(f"  Target: {target}")
    if company:
        click.echo(f"  Company: {company}")
    click.echo(f"{'='*60}\n")
    
    # Initialize profile with seed data
    profile = TargetProfile(
        name=target,
        email=email,
        company=company,
        role=role,
        linkedin=linkedin,
        twitter=twitter,
        github=github,
        domain=domain
    )
    
    # Initialize LLM client
    llm = LLMClient(config["llm"])
    
    # Run the agentic loop
    loop = AgentLoop(
        profile=profile,
        llm=llm,
        config=config,
        verbose=verbose,
        max_iterations=max_iterations
    )
    
    click.echo("[*] Starting discovery loop...\n")
    profile = loop.run()
    
    click.echo("\n[*] Running PHLRA analysis...")
    profile = loop.run_analysis()
    
    # Save profile
    output_path = output or f"data/profiles/{target.lower().replace(' ', '-')}-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    with open(output_path, "w") as f:
        json.dump(profile.to_dict(), f, indent=2, default=str)
    
    click.echo(f"\n[+] Profile saved to: {output_path}")
    
    # Print summary
    click.echo(f"\n{'='*60}")
    click.echo("  SUMMARY")
    click.echo(f"{'='*60}")
    click.echo(f"  Accounts found: {len(profile.accounts)}")
    click.echo(f"  Content items: {len(profile.content)}")
    click.echo(f"  Behavioral signals: {len(profile.behavioral.get('signals', []))}")
    click.echo(f"  PHLRA confidence: {profile.phlra_scores.get('confidence', 'N/A')}")
    
    if profile.phlra_scores.get("vulnerabilities"):
        click.echo(f"  Top vulnerabilities:")
        for v in profile.phlra_scores["vulnerabilities"][:3]:
            click.echo(f"    - [{v.get('severity', '?')}] {v.get('name', 'Unknown')}")
    
    click.echo(f"{'='*60}\n")


@cli.command()
@click.option("--profile", "-p", required=True, help="Profile JSON file")
@click.pass_context
def analyze(ctx, profile):
    """Run analysis on existing profile."""
    config = ctx.obj["config"]
    
    with open(profile) as f:
        profile_data = json.load(f)
    
    target_profile = TargetProfile.from_dict(profile_data)
    llm = LLMClient(config["llm"])
    
    loop = AgentLoop(
        profile=target_profile,
        llm=llm,
        config=config,
        verbose=ctx.obj["verbose"]
    )
    
    click.echo("[*] Running PHLRA analysis...")
    target_profile = loop.run_analysis()
    
    # Save updated profile
    output_path = profile.replace(".json", "-analyzed.json")
    with open(output_path, "w") as f:
        json.dump(target_profile.to_dict(), f, indent=2, default=str)
    
    click.echo(f"[+] Analysis saved to: {output_path}")


@cli.command()
@click.option("--profile", "-p", required=True, help="Profile JSON file")
@click.option("--format", "-f", type=click.Choice(["json", "markdown", "html", "pdf"]), default="markdown")
@click.option("--output", "-o", help="Output file path")
@click.pass_context
def report(ctx, profile, format, output):
    """Generate report from analyzed profile."""
    with open(profile) as f:
        profile_data = json.load(f)
    
    target_profile = TargetProfile.from_dict(profile_data)
    generator = ReportGenerator(target_profile)
    
    if format == "json":
        report_content = generator.to_json()
        ext = "json"
    elif format == "markdown":
        report_content = generator.to_markdown()
        ext = "md"
    elif format == "html":
        report_content = generator.to_html()
        ext = "html"
    elif format == "pdf":
        report_content = generator.to_pdf()
        ext = "pdf"
    
    output_path = output or profile.replace(".json", f"-report.{ext}")
    
    if format == "pdf":
        with open(output_path, "wb") as f:
            f.write(report_content)
    else:
        with open(output_path, "w") as f:
            f.write(report_content)
    
    click.echo(f"[+] Report saved to: {output_path}")


@cli.command()
@click.pass_context
def tools(ctx):
    """List available tools and their status."""
    from tools import AVAILABLE_TOOLS
    
    click.echo("\nAvailable Tools:")
    click.echo("-" * 40)
    
    for name, tool_class in AVAILABLE_TOOLS.items():
        tool = tool_class()
        status = "✓ installed" if tool.is_available() else "✗ not found"
        click.echo(f"  {name:15} {status}")
        click.echo(f"    Inputs: {', '.join(tool.input_types)}")
    
    click.echo()


@cli.command()
def init():
    """Initialize config file and directories."""
    # Create directories
    dirs = ["data/profiles", "data/reports", "data/raw"]
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        click.echo(f"[+] Created {d}/")
    
    # Create config if not exists
    if not os.path.exists("config.yaml"):
        config_template = """# SET Framework Configuration

llm:
  provider: claude  # claude or ollama
  model: claude-sonnet-4-20250514
  api_key: ${ANTHROPIC_API_KEY}
  
  # For Ollama:
  # provider: ollama
  # model: llama3.1:70b
  # endpoint: http://localhost:11434

tools:
  enabled:
    - sherlock
    - maigret
    - holehe
    - github
    - hibp
    - theharvester
  
  timeout: 120  # seconds per tool
  
  # Custom paths (if not in PATH)
  paths:
    # sherlock: /path/to/sherlock
    # maigret: /path/to/maigret

loop:
  max_iterations: 10
  saturation_threshold: 0.8  # Stop when profile is this complete
  min_confidence: 0.6

output:
  dir: ./data/reports
  save_intermediates: true

# API Keys (or use environment variables)
apis:
  hibp: ${HIBP_API_KEY}
  serpapi: ${SERP_API_KEY}
  proxycurl: ${PROXYCURL_API_KEY}
"""
        with open("config.yaml", "w") as f:
            f.write(config_template)
        click.echo("[+] Created config.yaml")
    else:
        click.echo("[*] config.yaml already exists")
    
    click.echo("\n[*] Next steps:")
    click.echo("  1. Edit config.yaml with your API keys")
    click.echo("  2. Install OSINT tools: pip install sherlock-project maigret holehe")
    click.echo("  3. Run: python set.py run --target 'John Doe' --email john@company.com")


if __name__ == "__main__":
    cli()
