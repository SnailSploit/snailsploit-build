# Burp MCP Security Analysis Toolkit

A skills-based security analysis framework for Claude Code, designed to analyze HTTP traffic from Burp Suite via MCP (Model Context Protocol).

## Philosophy

**Skills over Prompts**: Instead of ad-hoc prompts, this toolkit encodes expert security methodology into reusable skill files that Claude Code follows step-by-step.

**Phased Analysis**: Rather than analyzing everything at once, the pipeline moves through distinct phases:
1. Scope → 2. Triage → 3. Analyze → 4. Report

**Evidence-Required**: No finding without proof from actual HTTP traffic.

## Quick Start

```bash
# 1. Copy scope template and configure
cp templates/scope-template.yaml scope.yaml
# Edit scope.yaml with your target information

# 2. Ensure Burp Suite is running with MCP server enabled

# 3. In Claude Code, run commands:
"load scope"      # Validate configuration
"triage"          # Classify endpoints
"analyze all"     # Run all enabled indicators
"report"          # Generate final report
```

## Directory Structure

```
burp-mcp-toolkit/
├── CLAUDE.md                    # Main project context (auto-loaded by Claude Code)
├── README.md                    # This file
├── scope.yaml                   # Your engagement configuration (create from template)
│
├── skills/                      # Methodology files
│   ├── SKILL-burp-mcp.md        # MCP query patterns
│   ├── SKILL-endpoint-triage.md # Endpoint classification
│   ├── SKILL-idor-testing.md    # IDOR detection methodology
│   ├── SKILL-bola-testing.md    # Broken Object Level Auth
│   ├── SKILL-auth-analysis.md   # Auth bypass testing
│   ├── SKILL-ssrf-testing.md    # SSRF detection
│   ├── SKILL-injection-points.md# SQLi/XSS vector identification
│   └── SKILL-report-format.md   # Report generation format
│
├── templates/
│   ├── scope-template.yaml      # Blank scope configuration
│   └── finding-template.md      # Finding documentation format
│
├── output/                      # Generated during analysis
│   ├── endpoints.json           # Triage results
│   ├── findings/                # Per-indicator findings
│   │   ├── idor.md
│   │   ├── bola.md
│   │   ├── auth.md
│   │   ├── ssrf.md
│   │   └── injection.md
│   └── report.md                # Final consolidated report
│
└── lib/                         # Optional helper scripts
```

## Available Commands

| Command | Phase | Description |
|---------|-------|-------------|
| `load scope` | 1 | Parse and validate scope.yaml |
| `triage` | 2 | Classify and prioritize endpoints |
| `analyze {indicator}` | 3 | Run specific indicator analysis |
| `analyze all` | 3 | Run all enabled indicators |
| `report` | 4 | Generate consolidated report |
| `full scan` | 1-4 | Run complete pipeline |
| `status` | - | Show current progress |
| `show endpoints` | - | Display triaged endpoints |

## Indicators

| Indicator | Skill File | Description |
|-----------|------------|-------------|
| `idor` | SKILL-idor-testing.md | Insecure Direct Object Reference |
| `bola` | SKILL-bola-testing.md | Broken Object Level Authorization |
| `auth_bypass` | SKILL-auth-analysis.md | Authentication/session issues |
| `ssrf` | SKILL-ssrf-testing.md | Server-Side Request Forgery |
| `injection` | SKILL-injection-points.md | SQLi/XSS/Command injection |

## Prerequisites

1. **Burp Suite Professional** with MCP server extension enabled
2. **Claude Code** with MCP configured to connect to Burp
3. **HTTP Traffic** captured through Burp proxy
4. **Multiple auth contexts** (for IDOR/BOLA testing)

## Configuration

Edit `scope.yaml` to define:
- Target domains
- Include/exclude path patterns
- Enabled indicators
- Authentication tokens for different user contexts

See `templates/scope-template.yaml` for full documentation.

## Output

All findings are written to `output/`:
- `endpoints.json` - Triaged endpoint list
- `findings/{indicator}.md` - Per-indicator findings
- `report.md` - Consolidated final report

## Best Practices

1. **Always start with `load scope`** - Validates your configuration
2. **Run `triage` before `analyze`** - Ensures focused analysis
3. **Review endpoints.json** - Sanity check before deep analysis
4. **Check findings incrementally** - Don't wait for full scan
5. **Use multiple auth contexts** - Essential for authz testing

## Extending

To add new indicators:
1. Create `skills/SKILL-{indicator}-testing.md`
2. Add indicator to scope.yaml template
3. Update CLAUDE.md with new skill reference

## License

Internal use. Not for distribution.
